# LetterBob — prototype

## 1. Spotify
1. Crée une application dans le Spotify Developer Dashboard.
2. Copie son **Client ID**.
3. Dans `index.html`, remplace `TON_SPOTIFY_CLIENT_ID`.
4. Ajoute comme Redirect URI l'URL exacte de ton hébergement, par exemple `https://TON-COMPTE.github.io/LetterBob/`.
5. Héberge `index.html` sur GitHub Pages.

Le prototype utilise OAuth 2.0 Authorization Code + PKCE : aucun Client Secret n'est mis dans le navigateur.

## 2. Ce que fait déjà le prototype
- Recherche Spotify : albums, morceaux, artistes.
- Affichage des pochettes et métadonnées Spotify.
- Fiche d'une œuvre.
- Note de 1 à 10.
- Commentaire personnel.
- Journal des notes.
- Statistiques simples.
- Liens « Écouter sur Spotify ».
- Interface mobile sombre inspirée de l'univers BOB.
- Le Bob existant est réutilisé depuis l'ancien projet.

## 3. Prochaine étape pour une vraie application
Pour que les comptes, commentaires publics, abonnements, likes, listes et profils soient synchronisés entre appareils, il faudra brancher LetterBob à Supabase (comme ton projet BOB).
